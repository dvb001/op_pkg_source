extern int readwhackmsg(char *infile);
