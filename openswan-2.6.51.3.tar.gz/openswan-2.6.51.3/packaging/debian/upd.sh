ssh credil@galaxy.gatineau.credil.org bin/update-archive.sh
